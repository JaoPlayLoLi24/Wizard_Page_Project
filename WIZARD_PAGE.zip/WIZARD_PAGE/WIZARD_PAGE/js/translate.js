document.addEventListener("DOMContentLoaded", function () {
    var buttonTranslate = document.getElementById("button__translate");
    var allContentSection = document.getElementById("all-content");

    var originalContent = allContentSection.innerHTML; // Salva o conteúdo original

    var translated = false;

    buttonTranslate.addEventListener("click", function () {
        if (!translated) {
            // Traduz o conteúdo ao clicar
            allContentSection.innerHTML = getTranslatedContent();
        } else {
            // Restaura o conteúdo original ao clicar novamente
            allContentSection.innerHTML = originalContent;
        }

        translated = !translated; // Alterna o estado
    });

    function getTranslatedContent() {
        // Implemente a lógica de tradução aqui
        // Retorne o conteúdo traduzido como uma string HTML
        return '<h1>Objetivo do Projeto</h1>' +
            '<p>Ao nos aproximarmos do final do ano letivo, vamos revisitar nossa jornada através da língua inglesa, focando nas experiências únicas adquiridas ao explorar a Austrália. De suas paisagens diversas à sua fauna distintiva, foi uma jornada empolgante.</p>' +
            '<p>Nosso site serve como um hub central para todas as suas necessidades de aprendizado. Ele é projetado para tornar sua leitura e exploração de lições fáceis e agradáveis. Sem firulas, apenas acesso direto aos materiais do nosso projeto.</p>' +
            '<p>Acreditamos que a educação deve ser acessível a todos, e nossa plataforma reflete esse compromisso. Aprender inglês é para todos, e nosso site está aqui para apoiá-lo nessa jornada.</p>' +
            '<p>Ao concluirmos este ano letivo, nossa sincera gratidão se estende aos pais e professores que desempenharam um papel fundamental no sucesso de nossa comunidade. Sua dedicação e apoio incansáveis foram inestimáveis. Agradecemos por serem contribuintes essenciais em nossa jornada acadêmica. Desejamos a todos um merecido descanso e aguardamos ansiosamente por mais descobertas compartilhadas no próximo ano!</p>';
    }
});