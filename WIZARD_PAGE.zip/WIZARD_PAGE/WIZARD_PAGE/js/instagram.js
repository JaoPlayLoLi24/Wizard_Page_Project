function abrirNovaGuia(url) {
    window.open(url, '_blank');
}

document.getElementById('foto_luiza').addEventListener('click', function() {
    abrirNovaGuia('https://www.instagram.com/byylui/');
});

document.getElementById('nome_luiza').addEventListener('click', function() {
    abrirNovaGuia('https://www.instagram.com/byylui/');
});

document.getElementById('foto_giovanna').addEventListener('click', function() {
    abrirNovaGuia('https://www.instagram.com/giiovannalmeida_/');
});

document.getElementById('nome_giovanna').addEventListener('click', function() {
    abrirNovaGuia('https://www.instagram.com/giiovannalmeida_/');
});

document.getElementById('foto_thayna').addEventListener('click', function() {
    abrirNovaGuia('https://www.instagram.com/clownpiercee/');
});

document.getElementById('nome_thayna').addEventListener('click', function() {
    abrirNovaGuia('https://www.instagram.com/clownpiercee/');
});

document.getElementById('foto_bruna').addEventListener('click', function() {
    abrirNovaGuia('https://www.instagram.com/_bruna.almeida21/');
});

document.getElementById('nome_bruna').addEventListener('click', function() {
    abrirNovaGuia('https://www.instagram.com/_bruna.almeida21/');
});

document.getElementById('foto_joao').addEventListener('click', function() {
    abrirNovaGuia('https://www.instagram.com/jao.vieira05/');
});

document.getElementById('nome_joao').addEventListener('click', function() {
    abrirNovaGuia('https://www.instagram.com/jao.vieira05/');
});