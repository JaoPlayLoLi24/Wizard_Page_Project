let allContent = document.getElementById('all-content');
let contentPadrao = window.getComputedStyle(document.getElementById('all-content')).backgroundColor;
const tamanhoPadrao = 18;
let body = document.getElementById('body');
let header = document.getElementById('header');
let ulNav = document.getElementById('ulist');
let logoWizard = document.getElementById('logo-wizard');
let loguinho = document.getElementById('logo');
let footer = document.getElementById('footer');
let links = document.querySelectorAll('.a-from-list');
let elemento = document.querySelector('#languages');

let bodyPadrao = window.getComputedStyle(document.getElementById('body')).backgroundColor;
let headerPadrao = window.getComputedStyle(document.getElementById('header')).backgroundColor;
let ulNavPadrao = window.getComputedStyle(document.getElementById('ulist')).backgroundColor;
let logoWizardPadrao = window.getComputedStyle(document.getElementById('logo-wizard')).backgroundColor;
let logoPadrao = window.getComputedStyle(document.getElementById('logo')).backgroundColor;
let footerPadrao = window.getComputedStyle(document.getElementById('footer')).backgroundColor;
let linksPadrao = Array.from(links).map(link => window.getComputedStyle(link).backgroundColor);

var estado = false;
let brightnessOn = false;

function aumentar(){
    let tamanhoFonteAtual = window.getComputedStyle(allContent, null).getPropertyValue('font-size');
    let tamanhoAtualNumero = parseFloat(tamanhoFonteAtual);

    let tamanhoMaior = tamanhoAtualNumero + 1.1;
    allContent.style.fontSize = tamanhoMaior + 'px';
}

function diminuir(){
    let tamanhoFonteAtual = window.getComputedStyle(allContent, null).getPropertyValue('font-size');
    let tamanhoAtualNumero = parseFloat(tamanhoFonteAtual);

    let tamanhoMenor = tamanhoAtualNumero * 0.9;
    allContent.style.fontSize = tamanhoMenor + 'px';
}
function AutoContraste() {
    if(estado) {
    header.style.backgroundColor = 'black';
    body.style.backgroundColor = 'black';
    ulNav.style.backgroundColor = 'black';
    logoWizard.style.backgroundColor = 'black';
    loguinho.style.backgroundColor = 'black';
    allContent.style.backgroundColor = '#545353';
    allContent.style.color = 'white';
    footer.style.backgroundColor = '#545353'
    links.forEach(link => {
        link.style.color = 'white';
    });
}else {
    header.style.backgroundColor = headerPadrao;
    body.style.backgroundColor = bodyPadrao;
    ulNav.style.backgroundColor = ulNavPadrao;
    logoWizard.style.backgroundColor = logoWizardPadrao;
    loguinho.style.backgroundColor = logoPadrao;
    allContent.style.backgroundColor = contentPadrao;
    allContent.style.color = 'black';
    footer.style.backgroundColor = footerPadrao;
    links.forEach(link => {
        link.style.color = 'var(--firstColor)';
    });
}
estado = !estado;
}

function brilho(){
    brightnessOn = !brightnessOn;

    body.style.filter = brightnessOn ? 'brightness(1.5)' : 'brightness(1)';
}

function reset() {
    location.reload();
}