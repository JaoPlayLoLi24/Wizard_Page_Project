let todasClass = document.querySelector('.accessibility-button');

let botao = todasClass;

let conteudoDinamico = document.getElementById('hidden-content-for-accessibility');

function styleHidden() {
    conteudoDinamico.style.display = 'flex';
}

botao.addEventListener('click', () => {

    let estiloAtualDisplay = window.getComputedStyle(conteudoDinamico).display;

    if (estiloAtualDisplay === 'none') {

        styleHidden();

    }

    else {
        conteudoDinamico.style.display = 'none';
    }
});

let dataAtual = new Date();
let anoAtual = dataAtual.getFullYear();
let ano = document.getElementById('ano');
ano.innerText = anoAtual;


document.querySelector('.select_languages').addEventListener('change', function() {
    var selectedOption = this.options[this.selectedIndex];
    var selectedText = selectedOption.textContent;

    if (selectedText === 'Portuguese | BR' || selectedText === 'Português | BR') {
        window.location.href = 'index-pt' + '.html';
    } else if (selectedText === 'English | USA' || selectedText === 'Inglês | EUA') {
        window.location.href = 'index-en' + '.html';
    }
});

document.querySelector('#select_languages_cell').addEventListener('change', function() {
    var selectedOption = this.options[this.selectedIndex];
    var selectedText = selectedOption.textContent;

    if (selectedText === 'Portuguese | BR' || selectedText === 'Português | BR') {
        window.location.href = 'index-pt' + '.html';
    } else if (selectedText === 'English | USA' || selectedText === 'Inglês | EUA') {
        window.location.href = 'index-en' + '.html';
    }
});




let hamburguer = document.querySelector('.menu__btn');
let fundo = document.querySelector('.menu__box');

hamburguer.addEventListener("click", ()=> {
    var estiloAtual = getComputedStyle(fundo);
    var displayAtual = estiloAtual.display;
    fundo.style.display = (displayAtual === 'none' || displayAtual === '') ? 'block' : 'none';
})